import { KEYCHAIN_URL } from "../constants";
import { Keychain, KeychainOptions } from "../types";
import { WalletBridge } from "../wallets/bridge";
import { IFrame, IFrameOptions } from "./base";

type KeychainIframeOptions = IFrameOptions<Keychain> &
  KeychainOptions & {
    version?: string;
    ref?: string;
    refGroup?: string;
    needsSessionCreation?: boolean;
    username?: string;
    onSessionCreated?: () => void;
    encryptedBlob?: string;
  };

export class KeychainIFrame extends IFrame<Keychain> {
  private walletBridge: WalletBridge;

  constructor({
    url,
    policies,
    version,
    slot,
    namespace,
    tokens,
    preset,
    shouldOverridePresetPolicies,
    rpcUrl,
    ref,
    refGroup,
    needsSessionCreation,
    username,
    onSessionCreated,
    encryptedBlob,
    tokenBalanceProvider,
    ...iframeOptions
  }: KeychainIframeOptions) {
    const _url = new URL(url ?? KEYCHAIN_URL);
    const walletBridge = new WalletBridge();

    if (version) {
      _url.searchParams.set("v", encodeURIComponent(version));
    }

    // Handle tokenBalanceProvider - this takes precedence over deprecated `slot`
    if (tokenBalanceProvider) {
      _url.searchParams.set(
        "token_balance_provider",
        encodeURIComponent(JSON.stringify(tokenBalanceProvider)),
      );
      // Also set `ps` for torii provider for backwards compatibility with other features
      if (tokenBalanceProvider.type === "torii") {
        _url.searchParams.set(
          "ps",
          encodeURIComponent(tokenBalanceProvider.project),
        );
      }
    } else if (slot) {
      // Deprecated: support legacy `slot` option
      _url.searchParams.set("ps", encodeURIComponent(slot));
    }

    if (namespace) {
      _url.searchParams.set("ns", encodeURIComponent(namespace));
    }

    if (tokens?.erc20) {
      _url.searchParams.set(
        "erc20",
        encodeURIComponent(tokens.erc20.toString()),
      );
    }

    if (rpcUrl) {
      _url.searchParams.set("rpc_url", encodeURIComponent(rpcUrl));
    }

    if (ref) {
      _url.searchParams.set("ref", encodeURIComponent(ref));
    }

    if (refGroup) {
      _url.searchParams.set("ref_group", encodeURIComponent(refGroup));
    }

    if (needsSessionCreation) {
      _url.searchParams.set("needs_session_creation", "true");
    }

    if (username) {
      _url.searchParams.set("username", encodeURIComponent(username));
    }

    // Policy precedence logic:
    // 1. If shouldOverridePresetPolicies is true and policies are provided, use policies
    // 2. Otherwise, if preset is defined, use empty object (let preset take precedence)
    // 3. Otherwise, use provided policies or empty object
    if ((!preset || shouldOverridePresetPolicies) && policies) {
      _url.searchParams.set(
        "policies",
        encodeURIComponent(JSON.stringify(policies)),
      );
    } else if (preset) {
      _url.searchParams.set("preset", preset);
    }

    // Add encrypted blob to URL fragment (hash) if present
    // This contains the encrypted localStorage snapshot from keychain redirect
    if (encryptedBlob) {
      _url.hash = `kc=${encodeURIComponent(encryptedBlob)}`;
    }

    super({
      ...iframeOptions,
      id: "controller-keychain",
      url: _url,
      methods: {
        ...walletBridge.getIFrameMethods(),
        // Expose callback for keychain to notify parent that session was created and storage access granted
        onSessionCreated: (_origin: string) => () => {
          if (onSessionCreated) {
            onSessionCreated();
          }
        },
      },
    });

    this.walletBridge = walletBridge;

    // Expose the wallet bridge instance globally for WASM interop
    if (typeof window !== "undefined") {
      (window as any).external_wallets = this.walletBridge;
    }
  }

  getWalletBridge(): WalletBridge {
    return this.walletBridge;
  }
}
